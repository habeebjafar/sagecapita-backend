Hello <i>Sagecapita</i>,
<p>There's a newsletter signup request from the website.</p>
 
<p><u>Newsletter Signup request:</u></p>
 
<div>
<p><b>Email:</b>&nbsp;{{ $newslettersignup->email }}</p>
</div>
 
Thank You,
<br/>
<i>Sagecapita</i>