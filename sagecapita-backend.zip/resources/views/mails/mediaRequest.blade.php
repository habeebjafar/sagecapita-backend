Hello <i>Sagecapita</i>,
<p>There's a media request from the website</p>
 
<p><u>Media request:</u></p>
 
<div>
<p><b>Full Name:</b>&nbsp;{{ $mediarequest->fullName }}</p>
<p><b>Email:</b>&nbsp;{{ $mediarequest->email }}</p>
<p><b>Headline:</b>&nbsp;{{ $mediarequest->headline }}</p>
<p><b>Country:</b>&nbsp;{{ $mediarequest->country }}</p>
</div>
 
Thank You,
<br/>
<i>Sagecapita</i>