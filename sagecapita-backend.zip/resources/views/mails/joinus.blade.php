Hello <i>Sagecapita</i>,
<p>There's a join us request from the website</p>
 
<p><u>Join us request:</u></p>
 
<div>
<p><b>Full Name:</b>&nbsp;{{ $joinus->fullName }}</p>
<p><b>Email:</b>&nbsp;{{ $joinus->email }}</p>
<p><b>Phone:</b>&nbsp;{{ $joinus->phone }}</p>
<p><b>Role:</b>&nbsp;{{ $joinus->role }}</p>
<p><b>Country:</b>&nbsp;{{ $joinus->country }}</p>
<p><b>Language:</b>&nbsp;{{ $joinus->language }}</p>
<p><b>Message:</b>&nbsp;{{ $joinus->message }}</p>
</div>
 
Thank You,
<br/>
<i>Sagecapita</i>