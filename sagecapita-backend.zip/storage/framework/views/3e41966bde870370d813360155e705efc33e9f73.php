Hello <i>Sagecapita</i>,
<p>There's a media request from the website</p>
 
<p><u>Media request:</u></p>
 
<div>
<p><b>Full Name:</b>&nbsp;<?php echo e($mediarequest->fullName); ?></p>
<p><b>Email:</b>&nbsp;<?php echo e($mediarequest->email); ?></p>
<p><b>Headline:</b>&nbsp;<?php echo e($mediarequest->headline); ?></p>
<p><b>Country:</b>&nbsp;<?php echo e($mediarequest->country); ?></p>
</div>
 
Thank You,
<br/>
<i>Sagecapita</i><?php /**PATH C:\Users\HP\sagecapita-backend\resources\views/mails/mediarequest.blade.php ENDPATH**/ ?>