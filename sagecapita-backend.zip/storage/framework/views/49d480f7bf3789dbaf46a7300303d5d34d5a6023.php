<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\HP\sagecapita-backend\vendor\illuminate\mail/resources/views/text/button.blade.php ENDPATH**/ ?>