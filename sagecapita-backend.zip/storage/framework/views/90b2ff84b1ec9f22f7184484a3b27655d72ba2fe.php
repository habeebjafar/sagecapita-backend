<img src="https://sagecapita.com/assets/sagecapita.png" style="margin: 0 auto" />
Hi,
<p>Thank you for signing up to our newsletter.</p>
<p>As our super amazing friend, expect exciting useful tips and information periodically from us.</p>
 
Thank You,
<br/>
<i>Sagecapita</i><?php /**PATH C:\Users\HP\sagecapita-backend\resources\views/mails/newslettersignup_response.blade.php ENDPATH**/ ?>