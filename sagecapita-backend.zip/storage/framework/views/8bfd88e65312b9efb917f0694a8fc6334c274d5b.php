<?php echo e($slot); ?>

<?php /**PATH C:\Users\HP\sagecapita-backend\vendor\illuminate\mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>