Hello <i>Sagecapita</i>,
<p>There's a join us request from the website</p>
 
<p><u>Join us request:</u></p>
 
<div>
<p><b>Full Name:</b>&nbsp;<?php echo e($joinus->fullName); ?></p>
<p><b>Email:</b>&nbsp;<?php echo e($joinus->email); ?></p>
<p><b>Phone:</b>&nbsp;<?php echo e($joinus->phone); ?></p>
<p><b>Role:</b>&nbsp;<?php echo e($joinus->role); ?></p>
<p><b>Country:</b>&nbsp;<?php echo e($joinus->country); ?></p>
<p><b>Language:</b>&nbsp;<?php echo e($joinus->language); ?></p>
<p><b>Message:</b>&nbsp;<?php echo e($joinus->message); ?></p>
</div>
 
Thank You,
<br/>
<i>Sagecapita</i><?php /**PATH C:\Users\HP\sagecapita-backend\resources\views/mails/joinus.blade.php ENDPATH**/ ?>