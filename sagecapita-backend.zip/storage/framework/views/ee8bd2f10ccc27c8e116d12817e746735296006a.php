<?php echo e($slot); ?>

<?php /**PATH C:\Users\HP\sagecapita-backend\vendor\illuminate\mail/resources/views/text/footer.blade.php ENDPATH**/ ?>